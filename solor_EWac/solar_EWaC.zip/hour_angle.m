function [h,hs]=hour_angle(lt,lat,delta)
% This function caculate hour angle
% lt = local time
% lat = latitude
% delta = declination
% h = hour angle in an hour
% hs = hour angle in a day
% auther : minlunwu, Atmospheric Sciences, PCCU

if lat >90 | lat < -90
     error('LAT value MUST between -90 and 90')
end
rlat=(lat/180)*pi;

if abs(tan(rlat)*tan(delta)) >=1
    if rlat*delta > 0
    hs=pi;
    else
    hs=0;
    end
else
    hs=acos(-tan(rlat)*tan(delta)) ;
end

% et=(0.000075+0.001868*cos(gamma)-0.032077*sin(gamma)-0.014615*cos(2*gamma)-0.04089*sin(2*gamma))*229.18; %min
% lst=lt+(4*(lon-120.)+et)/60;  % time correction
lst=lt;
hra=(15*(12-lst)); %degree

if abs(hs)>0
   if hs==pi
   h=pi;
   else
   h=hra;
   end
else
h=0;
end

end