clear;close all
%% parameter
JD=[1:1:365]; %julian day
lat=[-90:1:90]; %latitude

%% JD related
[S,~]=distance(JD);
[delta]=declination(JD);

%% soloar radiation in all latitude in a year
Q=nan(181,365);
for lati=1:length(lat)
    for jdi=1:length(JD)
        [h,hs]=hour_angle(12,lat(lati),delta(jdi));
        [~,Q(lati,jdi)]=solar(S(jdi),delta(jdi),lat(lati),h,hs);
    end
end

%% figuration
contouriing_radiation(Q)

%% season comparison
 JD_sn(1)=julian_date(2020,3,21);    % spring 3/21
 JD_sn(2)=julian_date(2020,6,21);    % summer 6/21
 JD_sn(3)=julian_date(2020,9,23);    % fall 9/23
 JD_sn(4)=julian_date(2020,12,22);  % winter 12/22
 
[S_sn,~]=distance(JD_sn);
[delta_sn]=declination(JD_sn);

Q_sn=nan(4,181);
for lati= 1:length(lat)
  for i =1 : length(JD_sn)
   [h,hs]=hour_angle(12,lat(lati),delta_sn(i));
   [~,Q_sn(i,lati)]=solar(S_sn(i),delta_sn(i),lat(lati),h,hs);
  end
end
plot_season_allLAT(lat,Q_sn)

%% hourly comparison
%  TPE_lat=25.03;

% Q_hr=nan(4,24);
% for hh= 1:24
%   for i =1 : length(JD_sn)
%    [h,hs]=hour_angle(hh,TPE_lat,delta_sn(i));
%    [Q_hr(i,hh),~]=solar(S_sn(i),delta_sn(i),TPE_lat,h,hs);
%   end
% end
% 
% figure;plot ([1:24],Q_sn)
